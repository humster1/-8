fun main()
{

    println("Введите номер билета")
    val num:Int = readLine()!!.toInt()
    println("Введите пункт назначения")
    val mest:String = readLine()!!.toString()
    println("Введите количество дней в пути")
    val days: Int = readLine()!!.toInt()
    println("Введите время прибытия (формат ЧЧ:ММ)")
    val timeOut: String = readLine()!!.toString()
    println("Введите время стоянки (формат ЧЧ:ММ)")
    val timeIn: String = readLine()!!.toString()
    if(num < 0|| mest == ""|| days == null|| timeOut=="" || timeIn == "") println("Вы не ввели какуюто позицию")
    else
    {
        val Poezdka:Pract8= Pract8(num,mest,days,timeOut,timeIn)
        Poezdka.character()
        Poezdka.Day()
    }



    println("Название фильма")
    val name:String=readLine()!!.toString()
    println("Сеанс")
    val seans:Int = readLine()!!.toInt()
    println("Стоимость билетика")
    val price:Int=readLine()!!.toInt()
    println("Зал")
    val zal:Int=readLine()!!.toInt()
    println("Количество зрителей")
    val kolvo:Int=readLine()!!.toInt()
    if(name=="" || seans < 0 || price < 0 || zal < 0 || kolvo < 0) println("Вы не ввели какуюто позицию")
    else
    {
        val kinoteatr:Kino=Kino(name,seans,price,zal,kolvo)
        kinoteatr.character2()
        kinoteatr.bilet()
        kinoteatr.kolicstvo()
    }
}