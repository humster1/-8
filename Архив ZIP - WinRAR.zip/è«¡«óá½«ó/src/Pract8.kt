class Pract8 constructor(var num:Int,var mest:String,var days:Int,var timeOut:String, var timeIn:String) {
    fun character()
    {
        println("номер поездки $num, пункт назначния $mest, дни следования $days, время прибытия $timeOut часов и время стоянки $timeIn ")

    }
    fun Day() {
        when (days) {
            in 1..2 -> println("недолгая поездка $days в пути")
            in 3..4 -> println("средняя поездка $days в пути")
            in 5..7 -> println("долгая поездка $days в пути")
            else -> println("Очень долгая поездка")

        }
    }

}