class Kino constructor(var name:String,var seans:Int,var price:Int, var zal:Int, var kolvo:Int) {
    fun character2()
    {
        println("Название кинофильма $name, сеанс $seans , стоимость билета $price руб, зал $zal, количество зрителей $kolvo")
    }
    fun bilet()
    {
        when(price)
        {
            in 30..100->println("Дешманский билет")
            in 101..250->println("Средней-стоимости билет")
            in 251..500->println("Дорогой билет")
            in 501..5000->println("Билет для миллионеров")
            else-> println("Такой стоимости билета не может быть")
        }
    }
    fun kolicstvo()
    {
        when(kolvo)
        {
            in 50.. 150->println("Маленький зал")
            in 151..350->println("Средний зал")
            in 351..600-> println("Большой зал")
            else->println("Нет таких залов")
        }
    }
}